jQuery(function($) {
    var properties = {
        "space": "upqrcd1p9pa0",
        "token": "60e9aafdd61740af73fb0b087fe679f17ecb82acb9a45cc89f1e080124de9ee2",
        //  loading asset
        "asset": "7hA9Ny4QI8aIKyq40KeKkY",
        //  class to hold the campaigns
        "container": "alh-feed",
        //  attribute that holds the site id
        "attribute": "feed-site"
    };

    var client = contentful.createClient({
        space: properties.space,
        accessToken: properties.token,
        environment: 'master'
    });

    // Code using $ as usual goes here; the actual jQuery object is jq2
    $("." + properties.container).each(function(e) {
        var container = this;
        //  get the site id.
        var id = $(this).data(properties.attribute);
        if (id != "") {

            client.getEntries({
                "content_type": "itemFeeds",
                "fields.active": true,
                "fields.venueFeed": id,
            }).then(function(entries) {
                var data = [];
                entries.items.forEach(function(entry) {
                    //
                    if (entry.hasOwnProperty("fields") &&
                        entry.fields.hasOwnProperty("campaign_id") &&
                        entry.fields.campaign_id.hasOwnProperty("fields") &&
                        entry.fields.campaign_id.fields.hasOwnProperty("endDate")) {
                        // is there a future publish date?
                        if (entry.fields.campaign_id.fields.hasOwnProperty("publishDate")) {
                            var pd = entry.fields.campaign_id.fields.publishDate;
                            if (pd != null && pd.indexOf("-") !== 0) {
                                pd = pd.split("-");
                                var publishDate = new Date(pd[0], pd[1] - 1, pd[2], "03", "00", "00");
                            }
                        }

                        var ed = entry.fields.campaign_id.fields.endDate.split("-");
                        var endDate = new Date(ed[0], ed[1] - 1, ed[2], "03", "00", "00");
                        // increment the date by one day to ensure the end date time is tested for due to timezones
                        endDate.setDate(endDate.getDate() + 1);

                        if (entry.fields.campaign_id.fields.hasOwnProperty("image") &&
                            entry.fields.campaign_id.fields.image.hasOwnProperty("fields") &&
                            entry.fields.campaign_id.fields.image.fields.hasOwnProperty("file") &&
                            entry.fields.campaign_id.fields.image.fields.file.hasOwnProperty("url") &&
                            entry.fields.campaign_id.fields.active &&
                            (typeof publishDate == "undefined" || publishDate <= new Date()) &&
                            endDate > new Date()) {

                            var o = {
                                    "title": entry.fields.campaign_id.fields.name,
                                    "type": entry.fields.campaign_id.fields.type,
                                    "start": entry.fields.campaign_id.fields.startDate,
                                    "end": entry.fields.campaign_id.fields.endDate,
                                    "description": entry.fields.campaign_id.fields.description,
                                    "url": entry.fields.campaign_id.fields.buttonLink,
                                    "text": entry.fields.campaign_id.fields.buttonText,
                                    "image": entry.fields.campaign_id.fields.image.fields.file.url
                                }
                                //  set the data 
                            data.push(o);
                            // check the undefined value for event description
                            if (typeof o.description === "undefined") {
                                var eventDescription = "";
                            } else {
                                var eventDescription = o.description;
                            }
                            // print: {
                            //         console.log(o);
                            //         console.log("origin : " + document.location.origin); //https: //www.atmylocal.com.au
                            //     }
                            //Get venue details script below 
                            //var venueUrlF = window.location.hostname.replace("www.","");
                            var venueUrl = window.location.hostname.replace("www.", "");
                            //console.log("venueUrl comming from carausal : " + venueUrl);
                            var settings = {
                                "url": "https://alh-venues-api.herokuapp.com/venues/url/" + venueUrl + "",
                                "method": "GET",
                                "timeout": 0,
                            };
                            var URl = "https://alh-venues-api.herokuapp.com/venues/url/" + venueUrl + ""
                                //console.log("URl : " + URl);
                                // GET call to fetch the venue detais by venue URL
                            $.ajax(settings).done(function(resp) {
                                // print: {
                                //     console.log("Venue Details resp : " + resp); //get details of the venue
                                // }
                                //console.log("resp : " + resp);
                                var myJSON = JSON.stringify(resp);
                                var vObj = JSON.parse(myJSON);
                                //console.log("Venue Details object event schema : " +vObj);
                                //console.log("Venue Details object event schema vObj  : " + vObj[0]);
                                //  schema script JSON-LD creation
                                if (o.type[0] == "inventory" || o.type[0] == "ticketed") {
                                    var schemaScript = '{' +
                                        '"@context": "https://schema.org",' +
                                        '"@type": "Event", ' +
                                        '"name": "' + o.title + '", ' +
                                        '"startDate": "' + o.start + '", ' +
                                        '"endDate": "' + o.end + '", ' +
                                        '"eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode", ' +
                                        '"eventStatus": "https://schema.org/EventScheduled", ' +
                                        '"location": {' +
                                        '"@type": "Place",' +
                                        '"name": "' + vObj[0].name + '",' +
                                        '"address": {' +
                                        '"@type": "PostalAddress",' +
                                        '"streetAddress": "' + vObj[0].address + '",' +
                                        '"addressLocality": "' + vObj[0].addressLocality + '",' +
                                        '"postalCode": "' + vObj[0].postalCode + '",' +
                                        '"addressRegion": "' + vObj[0].addressRegion + '",' +
                                        '"addressCountry": "AU"' +
                                        '}' +
                                        '},' +
                                        '"image": "' + o.image + '", ' +
                                        '"description": "' + eventDescription + '", ' +
                                        '"organizer": {' +
                                        '"@type": "LocalBusiness",' +
                                        '"name": "' + vObj[0].name + '",' +
                                        '"url": "' + vObj[0].venueUrl + '",' +
                                        '"image": "' + vObj[0].logo + '",' +
                                        '"address": "' + vObj[0].address + '",' +
                                        '"priceRange": "$$",' +
                                        '"telephone": "' + vObj[0].phone + '"' +
                                        '}' +
                                        '}';

                                    // print: {
                                    //     console.log("Complete Schema Script : " + schemaScript);
                                    // }
                                    // print: {
                                    //         console.log("Event type for Above Schema : " + o.type[0]);
                                    //     }
                                    //pushing the JSON-ld script into
                                    var head = document.getElementsByTagName('head')[0],
                                        script = document.createElement('script');

                                    $(script).attr('type', 'application/ld+json');
                                    head.appendChild(script);
                                    $(script).append(schemaScript);
                                }

                            });
                            //console.log(venueUrl);


                        }

                    }
                });
                //  sort bt date.
                data.sort(function(a, b) {
                    var d = a.start.split("-");
                    var a = new Date(d[0], parseInt(d[1]) - 1, d[2]);

                    var d = b.start.split("-");
                    var b = new Date(d[0], parseInt(d[1]) - 1, d[2]);

                    return a.getTime() - b.getTime();
                });

                //  build the carousel
                if (data.length) {
                    //  clear the container 
                    container.innerHTML = "";
                    //  
                    $(container).addClass("carousel").css('opacity', '0');
                    // $(container).addClass("carousel").data - flickity('cellAlign', 'left');
                    //$(container).data - flickity('cellAlign', 'left');
                    var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

                    for (var i = 0; i < data.length; i++) {
                        //  create cell for campaign
                        var cell = document.createElement("div");
                        cell.className = "carousel-cell";


                        var a = false;
                        if (data[i].url != null && data[i].url.length) {
                            a = document.createElement("a");
                            a.className = "";
                            a.href = data[i].url;
                            a.target = "_blank";
                            a.title = (data[i].description != null ? data[i].description : (data[i].text != null ? data[i].text : "See more"));
                        }

                        //  create image for campaign cell slide
                        var img = document.createElement("img");
                        //  force consistancy in the image size for the carousel
                        img.src = "https:" + data[i].image + "?h=420&q=80";
                        img.style = "height:420px;max-width:none;";

                        img.onload = function() {
                                // console.log("WIdth: "+ img.width);
                                if (img.width != 0) {
                                    //cell.style = "width:"+ img.width +"px;";
                                }
                            }
                            //  add image to the dom.
                        if (a !== false) {
                            img.alt = a.title;
                            a.appendChild(img);
                            cell.appendChild(a);
                        } else {
                            cell.appendChild(img);
                        }
                        //


                        if (data[i].type.indexOf("event") !== -1 || data[i].type.indexOf("ticketed") !== -1) {
                            //  set event date.
                            var d = data[i].start.split("-");
                            var date = new Date(d[0], parseInt(d[1]) - 1, d[2]);

                            //  Build Date
                            var div = document.createElement("div");
                            div.className = "date-display";

                            var span = document.createElement("span");
                            span.className = "weekday";
                            span.innerHTML = weekdays[date.getDay()].substring(0, 3).toUpperCase();
                            div.appendChild(span);

                            var span = document.createElement("span");
                            span.className = "day";
                            span.innerHTML = date.getDate();
                            div.appendChild(span);

                            var span = document.createElement("span");
                            span.className = "month";
                            span.innerHTML = months[date.getMonth()].substring(0, 3).toUpperCase();
                            div.appendChild(span);
                            //
                            cell.appendChild(div);
                        }

                        var div = document.createElement("div");
                        div.className = "carousel-cell-footer";

                        //  No link, add title.
                        var t = document.createElement("div");
                        t.innerHTML = data[i].title;
                        //t.style = "width:100%;text-align:center;";
                        div.appendChild(t);

                        //  Build cell footer, does the image have a link?
                        if (a !== false) {
                            // more.              
                            var m = document.createElement("a");
                            m.target = "_blank";
                            m.href = a.href;
                            m.className = "more";
                            m.innerHTML = (data[i].text != null ? data[i].text : "See More") + " &#8594;";
                            //
                            div.appendChild(m);
                        }

                        cell.appendChild(div);
                        //            
                        container.appendChild(cell);
                    }
                    //  init. the carousel.
                    $(container).flickity({
                        // options
                        contain: true,
                        freeScroll: true,
                        wrapAround: false,
                        imagesLoaded: true,
                        autoPlay: true,
                        groupCells: true,
                        groupCells: 1,
                    });
                    //
                    setTimeout(function() {
                        $(container).animate({ "opacity": 1 });
                    }, 500);
                }
            });
        }
    });
});